This is a library for ESP8266 and the ST7789 IPS SPI display.

1.Install environment for dstike board  
https://github.com/spacehuhn/esp8266_deauther/wiki/Installation#compiling-using-arduino-ide
2.Install OLED library of this page  
3.Install Adafruit NeoPixel Library  
https://github.com/adafruit/Adafruit_NeoPixel  
4.Upload code example of this page to ESP-07

